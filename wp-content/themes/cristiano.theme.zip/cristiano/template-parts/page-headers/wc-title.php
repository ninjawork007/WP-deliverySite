<div id="page-title" class="color-content">
	<div class="center">
		<h1><?php woocommerce_page_title(); ?></h1>
	</div>
</div>