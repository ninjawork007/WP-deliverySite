<?php // !!! DEPRECATED !!! // ?>
<div id="page-header" style="background-image: url(<?php cristiano_header_image_wc(); ?>)"></div>