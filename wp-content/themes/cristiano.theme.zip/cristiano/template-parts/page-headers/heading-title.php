<div id="page-title" class="color-content">
	<div class="center">
		<h1 class="font-heading"><?php single_post_title(); ?></h1>
	</div>
</div>