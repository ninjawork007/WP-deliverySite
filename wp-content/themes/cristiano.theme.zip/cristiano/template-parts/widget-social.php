<div class="social">
	<?php do_action('restocore_social'); ?>
</div>