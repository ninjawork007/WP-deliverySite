<div class="section-title v1">
	<?php if (get_query_var('section_subtitle')) : ?>
		<p class="subtitle color-pr-tx"><?php echo get_query_var('section_subtitle'); ?></p>
	<?php endif; ?>
	<h3 class="font-heading"> <?php echo get_query_var('section_title'); ?></h3>		
</div>